import React from "react";
import TextEditor from "./TextEditor";

const TextEditorArea = () => {
  return (
    <>
      <TextEditor />
    </>
  );
};

export default TextEditorArea;
